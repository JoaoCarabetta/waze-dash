from .deckglplotly import deckglplotly

__all__ = [
    "deckglplotly"
]